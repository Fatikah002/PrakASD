package Kuis1_12_1C_FatikahSalsabilla;

import java.util.Scanner;

public class Libmain12 {
    public static void main(String[] args) {
     Scanner fatikah12 = new Scanner (System.in);
    Book12[] books = new Book12[1];
    boolean exit = false;

    while (true) {
        System.out.println("======== JTI Library ========");
        System.out.println("Menu : \n1. Input data buku \n2. Display Data \n4. Kurangi Stock \n5. exit");
        System.out.print("Select menu : ");
        String pilihMenu = fatikah12.nextLine();
        
        switch(pilihMenu){
            case "1":
            System.out.println("===============");
            System.out.print("Kode buku : ");
            String kodeBuku = fatikah12.nextLine();
            System.out.print("Judul Buku : ");
            String judulBuku = fatikah12.nextLine();
            System.out.print("Pengarang : ");
            String pengarang = fatikah12.nextLine();
            System.out.print("Tahun terbit : ");
            int tahunTerbit = fatikah12.nextInt();
            System.out.print("Stock : ");
            int stock = fatikah12.nextInt();
            System.out.println("Data berhasil ditambahkan");
            
            
            System.out.print("Kembali ke menu (y)? ");
            if (fatikah12.nextLine().equalsIgnoreCase("y")) {
                break;
            } else {
                System.exit(0);
            }
            break;
            
            case "2":
            System.out.println("==============");
            System.out.print("Kembali ke menu (y)? ");
            if (fatikah12.nextLine().equalsIgnoreCase("y")) {
                break;
            } else {
                System.exit(0);
            }
            break;
            
            case "3":
            System.out.println("Kurangi stock karena rusak");
             System.out.print("Kode buku : ");
            String updateName = fatikah12.nextLine();
            System.out.print("Kembali ke menu (y)? ");
                    if (fatikah12.nextLine().equalsIgnoreCase("y")) {
                        break;
                    } else {
                        System.exit(0);
                    }
                    break;
            
            case "4":
            System.out.print("Kembali ke menu (y)? ");
                    if (fatikah12.nextLine().equalsIgnoreCase("y")) {
                        break;
                    } else {
                        System.exit(0);
                    }
                    break;
             
            case "5":
            System.exit(0);
            break;
        }

    }
    }
   

}
