package Kuis1_12_1C_FatikahSalsabilla;


public class Transaksi12 {
    public String idTransaksi;
    public Book12[] arrBook;


   public Transaksi12(){
    arrBook = new Book12[4];
    this.idTransaksi = idTransaksi;
 
   }
   public void addData(Transaksi12 Book12){
   

   }

   
}
